# Expanding Footer

A Pen created on CodePen.io. Original URL: [https://codepen.io/joshualai/pen/XWVWJxg](https://codepen.io/joshualai/pen/XWVWJxg).

An expanding footer on hover

Best viewed in windows wider than 500px and taller than 600px.